---
name: numeric-flags-positive-int
description: "Every numeric flag in ctx ticket, source and wiki code must be parsed with positive_int(flag, text)"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 51c776c0-bc0d-404a-85e2-30e6d260e5d5
  modified: 2026-09-08T21:44:24.722Z
---

Every numeric flag in ticket, source and wiki code goes through `positive_int(flag, text)` in `src/ctx.c`. It dies naming the flag on junk or anything below 1. Don't use bare `atoi`/`strtol` there.

**Why:** the user asked for this as a standing rule after `ticket ready --limit` was first written with an ad hoc parser.

**How to apply:** when adding or touching a numeric flag in those areas, call the helper and add tests for 0, a negative and non-numeric input. Older `atoi` flags elsewhere (audit `--limit`, `--weeks`, `--days`) predate the rule and were not converted.
