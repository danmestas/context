---
name: date-flags-use-require-date
description: Every date flag in ctx must be validated by the existing require_date(); never add new date parsing
metadata:
  node_type: memory
  type: feedback
  originSessionId: 0b49c316-8afc-462f-be0d-97db450480fe
  modified: 2026-09-24T22:40:35.886Z
---

Every date flag in `src/ctx.c` goes through the existing `require_date(db, flag, value)`. No new date parsing, ever.

**Why:** the user stated this as a standing rule right after the `--review-after` vs `--retrieved` ordering check was added.

**How to apply:** when adding or touching a date flag, call `require_date` on it. Comparing two already-validated values (strict YYYY-MM-DD, so `strcmp` orders them) is fine; don't write new parsers (`strptime`, sscanf, manual splitting). Pairs with [[numeric-flags-positive-int]].
