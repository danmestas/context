---
name: feedback-redaction-rule-checklist
description: "Every new redaction rule's commit must bump REDACTION_VERSION and add a fuzz/seed/redact seed file"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 322c1486-c942-45f3-9d58-bbb744fb36b7
  modified: 2026-09-08T21:44:40.449Z
---

For every new redaction rule, in the same commit: (1) raise REDACTION_VERSION in src/ctx.c so stored turns are redacted again, and (2) add a seed file under fuzz/seed/redact/ exercising the rule.

**Why:** user stated it as a standing requirement after the sshpass rule commit lacked the seed.

**How to apply:** alongside the rule code and test/run.sh test, always check both before committing. See [[feedback-ctx-commit-rules]].
