---
name: feedback-redaction-commit-shows-effect
description: "Commits that change redaction must paste before/after of `ctx extract` on fuzz/seed/redact/mixed.txt in the commit body"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 35ecafc1-eaaf-43ce-981d-1055210b1fb7
  modified: 2026-10-02T22:42:47.206Z
---

Any commit that changes redaction behavior must include, in its body, a before/after of `ctx extract` run on fuzz/seed/redact/mixed.txt. A few lines of diff is enough.

**Why:** user wants each redaction change's effect visible in history (stated 2026-10-05).

**How to apply:** run `ctx extract` on mixed.txt before and after the change, paste the diff in the commit body. CLAUDE.md caps bodies at under 5 lines, so keep the diff to a few lines (trim to the changed lines). Complements [[feedback-redaction-rule-checklist]].
