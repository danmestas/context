---
name: feedback-ask-before-schema-changes
description: "Always ask the user before changing anything under schema/, even a comment"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 66ddf01c-86b3-4c8c-8d1f-39837c03537e
  modified: 2026-09-25T22:35:28.166Z
---

Ask the user before changing any file under `schema/` (index.sql, state.sql, ticket-table.sql, check.sql), every time, even for a comment-only edit.

**Why:** The user set this after I proposed a new `ctx_chunk.cut_bytes` column for tracking trimmed tool output. The schema is compiled into the binary and shapes existing databases, so they want to approve every change.

**How to apply:** Before any Edit/Write under `schema/`, stop and ask, saying what the change is. Approval for one change doesn't carry over to the next. This also applies when a feature plan includes a schema change: get approval for that part first. Related: [[feedback-redaction-rule-checklist]].
