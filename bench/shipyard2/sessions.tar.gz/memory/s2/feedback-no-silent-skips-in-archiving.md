---
name: feedback-no-silent-skips-in-archiving
description: "Archiving must never skip anything silently; every skip is counted and reported on stderr as \"N lines skipped\" when N > 0"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 7191ffce-d288-4a73-9446-a074325fc618
  modified: 2026-10-16T23:06:12.844Z
---

Nothing gets skipped silently anywhere in archiving (extract, archive, scan, relabel). Every skip is counted and reported, as `N lines skipped` on stderr when N > 0. Malformed JSON lines are skipped, never fatal.

**Why:** a transcript still being written always ends in a half line, so dying on bad lines is wrong; but silent skipping hides corruption.

**How to apply:** any new `continue`/drop path in archiving code needs a counter and a stderr report. Valid JSON that is not a turn (summary, sidechain, meta) is filtering, not a skip. A trailing half line that archive leaves for next time is deferred, not skipped. See `ex_report` in src/ctx.c.
