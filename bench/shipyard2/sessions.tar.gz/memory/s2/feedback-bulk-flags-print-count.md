---
name: feedback-bulk-flags-print-count
description: any flag that acts on many things at once must print how many it touched
metadata:
  type: feedback
---

Any flag that acts on many things at once prints how many it touched (e.g. `ctx audit --allow-rule` prints "N findings allowed", including 0).

**Why:** the user wants bulk actions to be visible and checkable, in the same spirit as [[feedback-no-silent-skips-in-archiving]].

**How to apply:** when adding a bulk flag, print the count and test that the number matches.
