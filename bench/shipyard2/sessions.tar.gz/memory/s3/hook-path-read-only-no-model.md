---
name: hook-path-read-only-no-model
description: Hard rule for ctx code - anything on the hook path must not write to the database or call a model; hooks only read and print
metadata:
  node_type: memory
  type: feedback
  originSessionId: 10b4fd9e-adae-4ffc-854c-962322275a44
  modified: 2026-09-11T21:46:09.884Z
---

Nothing that runs on the hook path may write to the database or call a model. Hooks read and print.

**Why:** the user stated it as a hard rule for this codebase (hooks have 3-5 s limits and must never disturb a session).

**How to apply:** before changing any hook-path code (`ticket offer`, `rules offer`, `artifacts keep`, `inject`, `recall`, `ctx hook`), check it against this rule. If a change seems to need a DB write or model call there, stop and ask the user first rather than working around it. Known existing tension to raise, not fix unprompted: `rules_offer` opens the DB read-write and runs `UPDATE ctx_rule_check SET asked = ...` (src/ctx.c ~6150); `ctx hook` forks a detached drain that runs archive/scan/propose/judge/sync (writes and model calls).
