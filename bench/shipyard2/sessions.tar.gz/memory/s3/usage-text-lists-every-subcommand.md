---
name: usage-text-lists-every-subcommand
description: Every subcommand of rules, decisions, artifacts must be in usage() in src/ctx.c and checked by name in test/run.sh
metadata:
  type: feedback
---

Every subcommand of `ctx rules`, `ctx decisions` and `ctx artifacts` appears in the usage text (`usage()` in src/ctx.c), and test/run.sh checks the usage output for it by name.

**Why:** the user stated it as a standing rule (2026-10-09) after finding hidden subcommands (propose-quiet, judge-quiet).
**How to apply:** when adding a subcommand to those three, update usage() and the name list in the usage test in the same topic.
