---
name: absolute-dates-only
description: Dates in any ctx output are absolute YYYY-MM-DD, never relative ("3 days", "yesterday")
metadata:
  type: feedback
---

Dates in any output (command output, docs, hook text) are absolute, YYYY-MM-DD, never relative like "3 days old" or "yesterday".

**Why:** relative text can't be pinned in a test and is wrong the moment it's archived. The user reverted an age-in-days column on `ctx decisions --open` for this.

**How to apply:** when output needs a point in time, print the date (e.g. `date('now', '+90 days')` computed in SQL). Durations used as settings or counts (`--days 14`) are fine.
