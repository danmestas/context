---
name: feedback-no-todo-files
description: Never leave TODO or notes files in the repo; report pending work in chat
metadata:
  node_type: memory
  type: feedback
  originSessionId: 2bacff10-775e-4f9f-83ee-62f6fd451f44
  modified: 2026-09-17T21:57:45.353Z
---

Never create TODO, notes, or pending-work files in the repo. Say what's pending in chat instead.

**Why:** The user loses track of such files.

**How to apply:** When work is deferred (e.g. remaining test cases), list it exactly in the chat reply. Don't write it to a file in the repo or leave a TODO comment as the only record.
