---
name: feedback-use-parse-count
description: "New numeric flag parsing must use parse_count, never atoi; leave existing atoi sites alone"
metadata:
  node_type: memory
  type: feedback
  originSessionId: cd11e50f-201d-480b-9c77-2900fd31631d
  modified: 2026-09-10T21:46:48.309Z
---

Never use atoi for anything new in ctx; always use `parse_count(flag, text)` in `src/ctx.c`. Leave the existing atoi/atol call sites alone unless the user asks to convert them.

**Why:** atoi silently accepts junk like `5x`; parse_count rejects trailing junk and values below 1 and names the flag. The user wants old sites untouched to keep diffs scoped.

**How to apply:** when adding a new numeric option, call `parse_count("--flag", argv[++i])`. Don't opportunistically convert other `--limit`/`--weeks`/`--days` sites. Note parse_count rejects 0, so flags where 0 is valid (e.g. `audit --limit 0` is used in tests) need to be raised with the user first.
