---
name: feedback-skill-md-same-commit
description: Changes to search/turn output or flags must update skill/ctx/SKILL.md in the same commit
metadata:
  type: feedback
---

Whenever `ctx search` or `ctx turn` output or flags change, update `skill/ctx/SKILL.md` in the same commit.

**Why:** agents learn the tool from that file, so drift makes them misuse it.
**How to apply:** treat it like the docs/howto.md rule in [[feedback-flag-docs-same-commit]]; check both before committing.
