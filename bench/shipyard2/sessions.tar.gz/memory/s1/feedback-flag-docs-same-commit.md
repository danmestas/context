---
name: feedback-flag-docs-same-commit
description: Every new CLI flag needs a line in docs/howto.md in the same commit as the code
metadata:
  node_type: memory
  type: feedback
  originSessionId: 4b72e8d0-a597-4d77-931c-f60f6aeaa8e1
  modified: 2026-09-08T21:44:21.251Z
---

Every new flag gets its line in docs/howto.md in the same commit as the code, never a later commit.

**Why:** I shipped `ctx search --count` without docs and the user had me amend it in.

**How to apply:** When adding a flag, edit docs/howto.md (the relevant section, e.g. "Search past work") before committing, alongside the usage text in src/ctx.c and the test in test/run.sh. See [[project-commit-rules]] for the other repo rules.
