---
name: fuzz-harness-header-comment
description: Every new fuzz/fuzz_*.c harness must start with a two-line comment (what it feeds, which bug classes it finds)
metadata:
  type: feedback
---

Every new fuzz harness starts with a two-line comment: what it feeds and which bug classes it is meant to find.

**Why:** user stated it as a standing rule when asking for the headers on the existing five harnesses.

**How to apply:** when adding `fuzz/fuzz_<name>.c`, begin with that comment, add a row to `fuzz/README.md` and seeds in `fuzz/seed/<name>/`. See [[new-make-targets-need-docs]] for the similar docs-with-change habit.
