---
name: check-scripts-fast-and-wired
description: "Rule for check scripts (e.g. tools/check_*.sh): under two seconds each, wired into make check in the same commit"
metadata:
  node_type: memory
  type: feedback
  originSessionId: edfcb8ac-b0a7-45a7-9e44-2efa4f4f51b2
  modified: 2026-09-28T22:50:41.980Z
---

Every check script finishes in under two seconds and is wired into `make check` in the same commit that adds it.

**Why:** the user stated this as a rule for check scripts right after `tools/check_docs.sh` was added (commit 7073c99, which already follows it).

**How to apply:** when adding a new check script, time it (it must run in under 2s), add its line to the `check:` recipe in the Makefile, and commit both together. Run the script directly, not `make check` (see CLAUDE.md). Related: [[new-make-targets-need-docs]].
