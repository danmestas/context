---
name: makefile-changes-show-dry-run
description: "For any Makefile change, run `make -n` on each touched target and paste the output in chat before committing"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 8a0212a5-fd5a-4bf5-896c-7ecd93c06819
  modified: 2026-10-13T23:07:22.614Z
---

For any Makefile change, run `make -n <target>` on each target touched and paste the output in chat before committing.

**Why:** User-stated rule (2026-10-14), so they can review what the changed targets would actually execute before the commit lands.

**How to apply:** After editing the Makefile and before `git commit`, run `make -n` per touched target (this is within the allowed `make` commands; `-n` only prints, doesn't run). Include the output in the chat message, not just a summary. Complements [[new-make-targets-need-docs]].
