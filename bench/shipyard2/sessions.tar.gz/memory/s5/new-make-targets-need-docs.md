---
name: new-make-targets-need-docs
description: "Every new make target needs a `##` description and a README mention in the same commit"
metadata:
  node_type: memory
  type: feedback
  originSessionId: a62d8506-f8c6-4027-800b-2e1738c0f326
  modified: 2026-09-08T21:44:16.904Z
---

Every new `make` target carries a `##` description comment on its target line (that is what `make help` lists), and the README's "Building and checks" section mentions it, all in the same commit as the target.

**Why:** the user asked for this when `make help` was added, so the target list stays discoverable and documented.
**How to apply:** when adding a target to the Makefile, add `## description` on the target line, add it to `.PHONY` if needed, and update README.md "Building and checks" before committing.
