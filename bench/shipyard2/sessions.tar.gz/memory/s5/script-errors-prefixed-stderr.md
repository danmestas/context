---
name: script-errors-prefixed-stderr
description: "Scripts print errors to stderr prefixed with their own name, e.g. `run.sh: ...`"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 9723c783-43f8-41a0-a3f0-16947f90178f
  modified: 2026-10-06T23:02:03.246Z
---

Every script in this repo prints its errors to stderr, prefixed with its own name, like `run.sh: ...`.

**Why:** User stated it as a rule after the `test/run.sh` missing-binary check (commit 28b6be1) was added.

**How to apply:** In any new or edited shell script, error messages go `echo "<script>.sh: ..." >&2`. Exit codes: 2 for "can't run", 1 for failure. See [[check-scripts-fast-and-wired]] for other script conventions.
